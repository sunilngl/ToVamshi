package com.imdm.ui.ldap;

import java.util.Collection;
import java.util.HashSet;

import org.springframework.ldap.core.DirContextOperations;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.ldap.userdetails.LdapAuthoritiesPopulator;

public class CustomLdapPopulator implements LdapAuthoritiesPopulator  {

    @Override
    public Collection<? extends GrantedAuthority> getGrantedAuthorities(DirContextOperations arg0, String arg1) {
        Collection<GrantedAuthority> authorities = new HashSet<GrantedAuthority>();
        authorities.add(new SimpleGrantedAuthority("USER"));
        return authorities;
    }
	
}